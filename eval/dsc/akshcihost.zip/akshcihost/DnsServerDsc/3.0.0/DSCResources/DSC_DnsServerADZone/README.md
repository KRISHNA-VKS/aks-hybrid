# Description

The DnsServerADZone DSC resource manages an AD integrated zone on a Domain Name System (DNS) server.
