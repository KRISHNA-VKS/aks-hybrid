# Description

The xADReplicationSubnet DSC resource will manage replication subnets.
